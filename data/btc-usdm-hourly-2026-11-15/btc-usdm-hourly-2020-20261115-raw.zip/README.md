# Original Binance BTCUSDT USD-M hourly archives

This package contains original Binance USD-M BTCUSDT perpetual traded-price and mark-price ZIPs with their official `.CHECKSUM` sidecars. Monthly archives cover 2020-01 through 2026-10; daily archives cover 2026-11-01 through 2026-11-15 and nine dates needed to repair missing mark-price hours in monthly files. All 203 ZIP digests were verified against the published checksums. `source-inventory-final.json` records URLs and verification status.

The original 2024-10-28 19:00, 20:00 and 21:00 UTC traded-price klines do not fully agree with the archived market trades; 20:00 is a zero-volume flat candle. Raw exchange files are intentionally unchanged. See the separately distributed prepared package for audit details and candidate reconstructed bars.

Timestamps in these USD-M source files are UTC Unix milliseconds. Trade and mark prices have different economic meanings; the mark-price volume field is not traded volume. No funding-rate data are included here.
