# BTCUSDT USD-M hourly research inputs

The package covers 2020-01-01 00:00 through 2026-11-15 23:00 UTC, inclusive. It contains 60,264 hourly traded-price candles, 60,264 hourly mark-price candles, and 2,511 daily price candles. The last timestamp is the most recent full UTC day available in Binance public daily archives when this snapshot was produced; it is not a live feed.

`prepared/user_data/data/binance/futures/` contains the original official-kline version and hourly mark prices in Freqtrade Feather format. The official traded-price data have a verified anomaly on 2024-10-28: the 20:00 UTC kline has zero volume despite archived market trades, and the 19:00 and 21:00 klines also disagree with archived trades. The official version preserves those values unchanged.

`prepared/reconstructed/user_data/data/binance/futures/` contains alternative traded-price hourly and daily files with these three hours reconstructed from the verified official raw market-trades archive. These are identified research candidates, not guaranteed exact exchange klines: the trade tape has ID gaps, and its hourly aggregates differ slightly from the separate aggregate-trade feed for some boundary quantities. The common mark-price file remains under the original prepared directory. The original trade and aggregate-trade URLs and SHA-256 digests are recorded in `quality-report.json`; detailed audits are included here.

`quality-report.json` gives source coverage, repairs and comparisons with the earlier research data. Timestamps are UTC. Mark prices are not trade prices, and mark `volume` is an exchange placeholder rather than traded volume. Original hourly exchange ZIPs and all 12 kline CSV fields are distributed separately alongside this package.

This package does not extend funding rates. The earlier funding dataset ends on 2026-10-31. These data are historical inputs, not evidence of completed backtesting, real fills or profitability.
