# BTC perpetual research inputs

This package contains selected public Binance BTCUSDT USD-M futures inputs for the BtcTrendV4 study. The study period is 2026-02-01 through 2026-10-31 UTC. The 2025-02 through 2026-10 source CSVs include the preceding year needed for warm-up; they are normalized local research copies, not byte-identical replicas of Binance ZIP archives. Four months (2025-02, 2026-02, 2026-06, 2026-10) were compared with verified official price and funding archives; see `evidence/official_input_sample_audit.json`. All 42 source CSVs were checked for expected timestamps, row counts and finite values.

`original-mark-archives/` contains nine unmodified official monthly 1-hour ZIPs and the unmodified 2026-06-29 daily 1-minute ZIP. June's monthly mark archive lacks June 29; the prepared data includes 24 hourly bars aggregated from that daily file, checked against the official daily 1-hour data.

`prepared/user_data/` contains daily futures candles and daily funding values from 2020-01-01 through 2026-10-31 and hourly mark candles for the study period. The `1h-funding_rate` filename is needed by the installed Freqtrade Binance adapter; it contains genuine 8-hour funding events, not interpolated hourly rates. Funding timestamps up to 47 ms from their nominal hour were aligned to the nearest hour to match hourly marks; this approximation can affect boundary events.

`source-manifest.json` records file checksums, data types, coverage checks and upstream URLs. No account databases or credentials are included. This package ends on 2026-10-31 and does not include later data.

These files do not establish profitability or complete a backtest. A Freqtrade run previously failed when Binance's market-information endpoint returned HTTP 451, and leverage and execution assumptions remain to be validated. There is no interpolation of missing market or funding records.
